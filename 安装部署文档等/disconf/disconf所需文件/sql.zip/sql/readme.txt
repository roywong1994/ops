此目录有所有SQL改动记录

请先后执行：

1-init_table.sql                主要是生成tables
2-data.sql                      主要是生成测试数据
20141201/disconf.sql            升级，支持 管理员角色、用户邮箱
20141226/disconf.sql            升级，支持 URL权限控制
20150101/disconf.sql            增加一个测试数据
20150320/disconf.sql            增加reloadable config的测试文件