#!/bin/sh
node parse.js